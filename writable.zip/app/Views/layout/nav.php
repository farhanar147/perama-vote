<!-- Navbar -->
<nav class="navbar navbar-light red-one">
		  <div class="container">
		    <a class="navbar-brand" style="color: #ffff;" href="/">
		      <img src="/img/perama.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
		     E-VOTING IBN
		    </a>
			<ul class="nav justify-content-end">
			  <li class="nav-item">
			    <a class="nav-link" style="color: #ffff;" aria-current="page" href="/">Beranda</a>
			  </li>
			  <li class="nav-item">
			    <a class="nav-link" style="color: #ffff;" href="/pages/cek_dpt">Cek DPT</a>
			  </li>
			  <li class="nav-item">
			    <a class="nav-link" style="color: #ffff;" href="/pages/biodata">Biodata Calon</a>
			  </li>
			  <li class="nav-item">
			    <a class="btn btn box" style="color: #ffff;" tabindex="-1" aria-disabled="true" href="/pages/login">Login Pemilih</a>
			  </li>
			  <li class="nav-item mx-2">
			    <a class="btn btn box" style="color: #ffff;" tabindex="-1" aria-disabled="true" href="/pages/admin_login">Login admin</a>
			  </li>
			</ul>
			</div>
		</nav>
		<!-- Navbar -->
